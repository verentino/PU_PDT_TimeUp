HOW TO USE:
1. Extract all the files into a folder (preferrably in path "D:\TimeUp").

2. Right click TimeUp.exe , select create shortcut.

3. Select the newly created shortcut, press Ctrl+X in your keyboard.

4. Still using windows explorer, head to path: "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"

5. Press Ctrl+V to paste the shortcut.

(Optional) Double-click the shortcut to try the app.